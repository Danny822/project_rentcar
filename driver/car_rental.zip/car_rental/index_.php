<?php

$page_name = 'index';

?>
<?php include __DIR__. '/__html_head.php'; ?>
<?php include __DIR__. '/__navbar.php'; ?>
<div class="container">


</div>
<?php include __DIR__. '/__html_foot.php'; ?>
